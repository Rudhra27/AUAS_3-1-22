package com.sdl.AUAS.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.GeneralinfoRepo;
import com.sdl.AUAS.Repository.UserRepository;
import com.sdl.AUAS.Service.UserService;

@Controller
public class UserController {
	
	@Autowired
	GeneralRepo grepo;
	@Autowired
	GeneralinfoRepo ginforepo;
	@Autowired
	UserRepository repo;
	UserService userservice;
	
	@RequestMapping("/")
	public String home(HttpServletRequest request)
	{
		return "index.html";
	}
	
	@GetMapping("/admin")
	public String admin()
	{
		return "admin/AdminLogin";
	}
	
	@GetMapping("/faculty")
	public String faculty()
	{
		return "users/Faculty";
	}
	@GetMapping("/staff")
	public String staff()
	{
		return "staff/Staff";
	}
	@GetMapping("/student")
	public String student()
	{
		return "students/Student";
	}
	@GetMapping("/homepage")
	public String homepage()
	{
		return "index";
	}
	@GetMapping("/terms")
	public String terms()
	{
		return "mainpage/Terms";
	}
	@GetMapping("Querytype")
	public String Querytype()
	{
		return "mainpage/Querytype";
	}
	@RequestMapping("/Querytype")
	public String Login() {
	    return "mainpage/Querytype";
	}
	@GetMapping("/privacy")
	public String privacy()
	{
		return "mainpage/Privacy";
	}
	@GetMapping("/join")
	public String join()
	{
		return "mainpage/Join";
	}
	@GetMapping("https://goo.gl/maps/bK7UCKr28dqNfGWb6")
	public String location()
	{
		return "mainpage/Location";
	}
	@GetMapping("/about")
	public String about()
	{
		return "mainpage/About";
	}
	
	@GetMapping("/Support")
	public ModelAndView Support()
	{
		//model.addAttribute("passuserid",passuserid);
		ModelAndView mav=new ModelAndView("mainpage/GeneralSupport");
		mav.addObject("generals",grepo.findAll());
		return mav;
	}

	@PostMapping("/increasecount")
	public String follow(@RequestParam("gid") Long gid,@Valid @ModelAttribute("general2") General general2, Model model) {
	    General general1 = new General();
	    //Long lid =generalinfo1.getGid();
	    general1 = grepo.findByGid(general2.getGid());


	    System.out.println(general2.getGid()+"enterred");
	    System.out.println(general1);

	    if(null!=general1)
	    {

	        System.out.println("IN");
	        int count=general1.getCount();
	        System.out.println("initial "+count);
	        count++;
	        System.out.println("update "+count);
	        model.addAttribute("count" , count);
	        general1.setCount(count);
	        grepo.save(general1);
	        return "redirect:/Support";
	    }
	    else

	        return "redirect:/";
	  }
	}
	
	


