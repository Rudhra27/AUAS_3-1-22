package com.sdl.AUAS.Service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.User;
import com.sdl.AUAS.Repository.UserRepository;

@Service
public class UserService implements UserDetailsService {
  
  private UserRepository userRepo;

  @Autowired
  public void setUserRepository(UserRepository userRepository) {
    this.userRepo = userRepository;
  }
  
  public void save(User user) {
    userRepo.save(user);
  }

@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	// TODO Auto-generated method stub
	return null;
}


}
