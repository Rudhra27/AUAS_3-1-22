package com.sdl.AUAS.Model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name="Library")
public class Library {
	
	@Id
	public long key;
	private String bname;
	private String author;
	private String edition;
	
	@Lob
	  @Column(name = "image")
	  private byte[] image;
	@Column(name="Time")
	 @Temporal(TemporalType.TIMESTAMP)
	    private Date utilDate;
	private String status;
	public long getKey() {
		return key;
	}
	public void setKey(long key) {
		this.key = key;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public Date getUtilDate() {
		return utilDate;
	}
	public void setUtilDate(Date utilDate) {
		this.utilDate = utilDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Library [key=" + key + ", bname=" + bname + ", author=" + author + ", edition=" + edition + ", image="
				+ Arrays.toString(image) + ", utilDate=" + utilDate + ", status=" + status + "]";
	}
	public Library(long key, String bname, String author, String edition, byte[] image, Date utilDate, String status) {
		super();
		this.key = key;
		this.bname = bname;
		this.author = author;
		this.edition = edition;
		this.image = image;
		this.utilDate = utilDate;
		this.status = status;
	}
	
	public Library()
	{
		
	}
	}
