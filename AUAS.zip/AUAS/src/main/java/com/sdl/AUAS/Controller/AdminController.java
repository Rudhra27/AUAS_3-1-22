package com.sdl.AUAS.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sdl.AUAS.Model.Admin;
import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Repository.AdminRepo;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.LibraryRepo;
import com.sdl.AUAS.Repository.LibraryinfoRepo;

@Controller
public class AdminController {
	

	@Autowired
	AdminRepo arepo;
	@Autowired 
	 LibraryRepo libRepo;
	@Autowired 
	 LibraryinfoRepo lRepo;
	@Autowired 
	GeneralRepo gRepo;
	
	@PostMapping("/LoginAdmin")
	public String LoginAdmin(@Valid @ModelAttribute("admin") Admin admin, Model model)
	{
		Admin admin1=new Admin();
		
		
		
		admin1=arepo.findByAdid(admin.getAdid());
		if(null!=admin1)
		{
			if(admin.getAdpassword().equals(admin1.getAdpassword()))
					
			{
				if(admin.getAdid()==1000000001)
				{
					return "admin/dpselect";
				}
				if(admin.getAdid()==1000000002)
				{
					return "admin/HostelOffice";
				}
				if(admin.getAdid()==1000000003)
				{
					return "admin/libselect";
				}
			}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "admin/AdminLogin";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "admin/AdminLogin";
		}
		return "admin/AdminLogin";
	}
	

	@GetMapping(value="/Dept")
	public ModelAndView Dept()
	{
		ModelAndView mav = new ModelAndView();
		mav.addObject("departments",gRepo.findAll());
		mav.setViewName("admin/DeptOffice");
		return mav;
	}
	@PostMapping("/Dept")
	public String follow(@RequestParam("gid") Long gid,@Valid @ModelAttribute("general2") General general2, Model model) {
	    General general1 = new General();
	    //Long lid =generalinfo1.getGid();
	    general1 = gRepo.findByGid(general2.getGid());

	    System.out.println(general2.getGid()+"enterred");
	    System.out.println(general1);

	    if(null!=general1)
	    {

	        
	        general1.setStatus("Solved");
	        gRepo.save(general1);
	        return "redirect:/Dept";
	    }
	    else
	        return "redirect:/";
	  }
	@GetMapping("/LibraryQueries")
	public ModelAndView LibraryQueries() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("library",libRepo.findAll());
		mav.setViewName("admin/Library");
		return mav;
	}
}
