package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student,Integer>{

	Student findBySid(Long sid);

}
