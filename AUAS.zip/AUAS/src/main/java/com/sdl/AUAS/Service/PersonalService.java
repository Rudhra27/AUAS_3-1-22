package com.sdl.AUAS.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;


@Repository
@Transactional
public class PersonalService {
	private PersonalinfoRepo prepo;
	
	 @Autowired
	  public void setPersonalinfoRepo(PersonalinfoRepo prepo) {
	    this.prepo = prepo;
	 }
	 @Transactional
		public int saveImage(Personalinfo personal) {
			
		      try {
		          prepo.save(personal);
		          return 1;
		      } catch (Exception e) {
		           return 0;
		      }
	
	}
	public Personalinfo loadByUserid(Long passuserid) {
		// TODO Auto-generated method stub
		return null;
	}
}
