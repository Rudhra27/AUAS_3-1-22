
var myInput = document.getElementById("spassword");
var myInput2 = document.getElementById("cpassword");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");
var final = document.getElementById("final");

const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#spassword');

togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye / eye slash icon
    this.classList.toggle('bi-eye');
});


const ctogglePassword = document.querySelector('#ctogglePassword');
const cpassword = document.querySelector('#cpassword');

ctogglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = cpassword.getAttribute('type') === 'password' ? 'text' : 'password';
    cpassword.setAttribute('type', type);
    // toggle the eye / eye slash icon
    this.classList.toggle('bi-eye');
});


// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("passwordvalidationcontainer").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("passwordvalidationcontainer").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
var checkCaps= false , checkNum = false, checkLen = false , checkLower = false; 
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
    checkLower = true;
	
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
	checkLower = false;
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
    checkCaps= true;
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
    checkCaps= false;
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
    checkNum = true;
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
    checkNum = false
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
    checkLen = true;
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
    checkLen = false; 
  }


  // Validate length
  if((checkCaps== true) && (checkNum == true) && (checkLen== true) && (checkLower == true)) {
    final.classList.remove("invalid");
    final.classList.add("valid");
    checkfinal = true;
  } else {
    final.classList.remove("valid");
    final.classList.add("invalid");
    checkfinal = false; 
  }
		if(checkfinal == false) {
		myInput.setCustomValidity("Password must be atleast 8 characters with a mix of Capital and Small letters; symbols and numbers");
		} 
		else {
		 myInput.setCustomValidity('');
		   }
		 myInput.onchange ;
		 myInput.onkeyup ;
	  
  

	  var password = document.getElementById("spassword");
	  var confirm_password = document.getElementById("cpassword");
	  
	  function validatePassword(){
		   if(password.value != confirm_password.value) {
		 confirm_password.setCustomValidity("Passwords Don't Match");
		   } else {
		 confirm_password.setCustomValidity('');
		   }
		 }
		 password.onchange = validatePassword;
		 confirm_password.onkeyup = validatePassword;
	  



}